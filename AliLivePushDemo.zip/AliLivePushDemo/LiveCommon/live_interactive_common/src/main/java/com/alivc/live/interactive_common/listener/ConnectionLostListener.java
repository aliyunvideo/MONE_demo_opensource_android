package com.alivc.live.interactive_common.listener;

public interface ConnectionLostListener {
   void onConfirm();
}
