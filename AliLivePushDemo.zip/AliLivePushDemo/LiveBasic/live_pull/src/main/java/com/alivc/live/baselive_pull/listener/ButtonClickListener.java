package com.alivc.live.baselive_pull.listener;

public interface ButtonClickListener {
    void onButtonClick(String message, int position);
}
