package com.alivc.live.baselive_push.adapter;

public interface OnSoundEffectChangedListener {
    void onSoundEffectChangeVoiceModeSelected(int position);

    void onSoundEffectRevertBSelected(int position);
}
