package com.alivc.live.beauty.constant;

public class BeautyConstant {
    public static final String BEAUTY_QUEEN_MANAGER_CLASS_NAME = "com.alivc.live.queenbeauty.QueenBeautyImpl";
    public static final String BEAUTY_INTERACT_QUEEN_MANAGER_CLASS_NAME = "com.alivc.live.queenbeauty.InteractQueenBeautyImpl";
    public static final String BEAUTY_QUEEN_DATA_INJECTOR_CLASS_NAME = "com.alivc.live.queenbeauty.QueenBeautyUIDataInjector";
}
