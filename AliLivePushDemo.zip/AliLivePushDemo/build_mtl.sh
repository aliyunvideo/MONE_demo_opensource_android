#! /bin/sh
#
# build_mtl.sh
#
# Created by keria on 2022/08/30
# Copyright (C) 2022 keria <runchen.brc@alibaba-inc.com>
#
set -e

# shellcheck disable=SC2164
SHELL_FOLDER=$(
  cd "$(dirname "$0")"
  pwd
)

# when u use the build type for building debug or release outputs
# u need to export a env into system, such as:
#'export BUILD_TYPE_ENV=debug'

# build live push demo + aio sdk
#./build_mtl.sh -p aio

# build live push demo + live push sdk
#./build_mtl.sh

# build type, build live push demo, interactive push demo or aio demo.
#build_type='basic'
build_type='interactive'
#build_type='aio'

sdk_version=''

#if use fast mode, do not refresh gradle dependencies
fast_mode=0

#if build with formal version, we need remove all the test code.
release_official=0

aio_ui_foundation_branch='develop'
aio_third_party_branch='master'

log() {
  echo "[BUILD-DEMO] [$(date +'%Y/%m/%d %H:%M:%S')]: ${1}"
}

prepare_mtl_build_env() {
  log 'prepare mtl build env...'
  export JAVA_HOME=/usr/alibaba/jdk1.8.0_25
  export PATH=$JAVA_HOME/bin:$PATH
  export ANDROID_NDK_HOME=/home/admin/software/android-ndk-r18b
  log 'prepare mtl build env over!'
}

# Here we need to import aio common modules
prepare_code_repo() {
  log 'prepare code repo...'

  # Attention!!!
  # We've put `AndroidThirdParty` into the gitignore in order to make it always the latest,
  # so, we need to `git pull` the latest commits on master branch at the beginning.
  if [ ! -d "AUIFoundation" ]; then
    # shellcheck disable=SC2154
    if [ "$aio_ui_foundation_branch_override" != "" ]; then
      aio_ui_foundation_branch=$aio_ui_foundation_branch_override
    fi
    log "now clone ui foundation from branch: $aio_ui_foundation_branch"
    git clone --branch "$aio_ui_foundation_branch" git@gitlab.alibaba-inc.com:AlivcSolution_Android/AUIFoundation.git
    git submodule init && git submodule update --init --recursive
  fi

  if [ ! -d "AndroidThirdParty" ]; then
    # shellcheck disable=SC2154
    if [ "$aio_third_party_branch_override" != "" ]; then
      aio_third_party_branch=$aio_third_party_branch_override
    fi
    log "now clone third party from branch: $aio_third_party_branch"
    git clone --branch "$aio_third_party_branch" git@gitlab.alibaba-inc.com:AlivcSolution_Android/AndroidThirdParty.git
    git submodule init && git submodule update --init --recursive
  fi

  log 'prepare code repo over!'
}

clean_cache() {
  log 'clean cache...'
  rm -rf .gradle/ && ./gradlew clean --stacktrace --info || exit 1
  log 'clean cache over...'
}

refresh_gradle_dependencies() {
  log 'refresh gradle dependencies...'
  ./gradlew --refresh-dependencies --stacktrace --info || exit 1
  log 'refresh gradle dependencies over!'
}

package_source_code() {
  log 'package source code...'
  ./gradlew clean -Pczip=1 --stacktrace --info || exit 1
  log 'package source code over!'
}

build_demo_debug() {
  log 'build debug demo...'
  ./gradlew assembleDebug --stacktrace --info || exit 1
  log 'build debug demo over!'
}

build_demo_release() {
  log 'build release demo...'
  ./gradlew assembleRelease --stacktrace --info || exit 1
  log 'build release demo over!'
}

change_demo_type() {
  if [ "$build_type" = "aio" ]; then
    change_to_aio
  elif [ "$build_type" = "interactive" ]; then
    change_to_interactive
  else
    change_to_basic
  fi
}

change_to_interactive() {
  log 'change to interactive...'

  # shellcheck disable=SC2039
  if [[ $(uname) == 'Darwin' ]]; then
    sed -i '' 's/allInOne=.*/allInOne=false/g' gradle.properties
    sed -i '' 's/SDK_TYPE=.*/SDK_TYPE=AliVCSDK_InteractiveLive/g' gradle.properties
  fi
  # shellcheck disable=SC2039
  if [[ $(uname) == 'Linux' ]]; then
    sed -i 's/allInOne=.*/allInOne=false/g' gradle.properties
    sed -i 's/SDK_TYPE=.*/SDK_TYPE=AliVCSDK_InteractiveLive/g' gradle.properties
  fi

  # shellcheck disable=SC2039
  if [ -n "$sdk_version" ]; then
    log "change to sdk version ${sdk_version}..."
    # shellcheck disable=SC2039
    if [[ $(uname) == 'Darwin' ]]; then
      sed -i '' "s/com.alivc.pusher:AlivcLivePusher_Interactive:.*/com.alivc.pusher:AlivcLivePusher_Interactive:$sdk_version\"/g" AndroidThirdParty/config.gradle
    fi
    # shellcheck disable=SC2039
    if [[ $(uname) == 'Linux' ]]; then
      sed -i "s/com.alivc.pusher:AlivcLivePusher_Interactive:.*/com.alivc.pusher:AlivcLivePusher_Interactive:$sdk_version\"/g" AndroidThirdParty/config.gradle
    fi
  fi

  log 'change to interactive over!'
}

# TODO now not support.
change_to_aio() {
  log 'change to aio...'

  # shellcheck disable=SC2039
  if [[ $(uname) == 'Darwin' ]]; then
    sed -i '' 's/allInOne=.*/allInOne=true/g' gradle.properties
  fi
  # shellcheck disable=SC2039
  if [[ $(uname) == 'Linux' ]]; then
    sed -i 's/allInOne=.*/allInOne=true/g' gradle.properties
  fi

  log 'change to aio over!'
}

change_to_basic() {
  log 'change to basic...'

  # shellcheck disable=SC2039
  if [[ $(uname) == 'Darwin' ]]; then
    sed -i '' 's/allInOne=.*/allInOne=false/g' gradle.properties
    sed -i '' 's/SDK_TYPE=.*/SDK_TYPE=AliVCSDK_BasicLive/g' gradle.properties
  fi
  # shellcheck disable=SC2039
  if [[ $(uname) == 'Linux' ]]; then
    sed -i 's/allInOne=.*/allInOne=false/g' gradle.properties
    sed -i 's/SDK_TYPE=.*/SDK_TYPE=AliVCSDK_BasicLive/g' gradle.properties
  fi

  # shellcheck disable=SC2039
  if [ -n "$sdk_version" ]; then
    log "change to sdk version ${sdk_version}..."
    # shellcheck disable=SC2039
    if [[ $(uname) == 'Darwin' ]]; then
      sed -i '' "s/com.alivc.pusher:AlivcLivePusher:.*/com.alivc.pusher:AlivcLivePusher:$sdk_version\"/g" AndroidThirdParty/config.gradle
    fi
    # shellcheck disable=SC2039
    if [[ $(uname) == 'Linux' ]]; then
      sed -i "s/com.alivc.pusher:AlivcLivePusher:.*/com.alivc.pusher:AlivcLivePusher:$sdk_version\"/g" AndroidThirdParty/config.gradle
    fi
  fi

  log 'change to basic over!'
}

fix_agp_build_failure_patch() {
  curl -L -o 33.0.2.tar.gz https://mtl4.alibaba-inc.com/scheduler/jobs/5316374/artifacts/461ecf2328284be8977f5544c4d91763/download/build_tools.tar.gz
  mv 33.0.2.tar.gz /usr/alibaba/android-sdk-linux/build-tools/33.0.2.tar.gz
  cd /usr/alibaba/android-sdk-linux/build-tools
  tar -xzf 33.0.2.tar.gz
  cd 33.0.2
  ln -s d8 dx
  cd lib
  ln -s d8.jar dx.jar

  cd $SHELL_FOLDER
}

mtl_build() {
  prepare_mtl_build_env || exit 1
  fix_agp_build_failure_patch || exit 1
  prepare_code_repo || exit 1
  clean_cache || exit 1
  if [ $fast_mode = 0 ]; then
    refresh_gradle_dependencies || exit 1
  fi
  change_demo_type || exit 1
  if [ $release_official = 1 ]; then
    package_source_code || exit 1
  fi
  # shellcheck disable=SC2154
  if [ "$BUILD_TYPE_ENV" = "debug" ]; then
    build_demo_debug || exit 1
  else
    build_demo_release || exit 1
  fi
}

log '*** start build ***'
start=$(date +%s)

while getopts 'cdfrithop:q:v' optname; do
  case "$optname" in
  'c') clean_cache ;;
  'd') build_demo_debug ;;
  'f') fast_mode=1 ;;
  'r') build_demo_release ;;
  'i') prepare_code_repo ;;
  't') mtl_build ;;
  'h') log 'HELP!!!' ;;
  'o') release_official=1 ;;
  'p') build_type="$OPTARG" ;;
  'q') sdk_version="$OPTARG" ;;
  'v') log "current version is "$(git rev-parse --short HEAD) ;;
  ?) log 'Unknown error while processing options' ;;
  esac
done

end=$(date +%s)
time=$(echo "$start" "$end" | awk '{print $2-$1}')

log "*** end build, cost: ${time}s. ***"
